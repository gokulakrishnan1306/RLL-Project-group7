import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiuserService } from '../services/apiuser.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit {
  



  constructor(private router: Router, private userService: ApiuserService) { }

  ngOnInit(): void {
  }
  email: string = '';
  password: string = '';
  newPassword: string = '';
  confirmNewPassword: string = '';

  onSubmit() {
    if (this.newPassword !== this.confirmNewPassword) {
      // Display an error message or handle password mismatch
      //alert("not valid")
      return;
    }
    // else{
       alert(" Password Reset successful")

    this.userService.resetPassword(this.email,this.password, this.newPassword)
      .subscribe(
        () => {
          alert(" Password Reset successful");
          // Password reset successful, show a success message or navigate to a success page
        },
      );
}

goBack() {
  this.router.navigate(['/userlogin']); // Navigate back to the admin dashboard
}

}