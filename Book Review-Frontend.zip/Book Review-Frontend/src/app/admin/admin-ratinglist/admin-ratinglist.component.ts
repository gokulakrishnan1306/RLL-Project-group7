import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'; // Import Router
import { ApireviewService } from 'src/app/services/apireview.service';
import { Review } from 'src/app/Review';

@Component({
  selector: 'app-admin-ratinglist',
  templateUrl: './admin-ratinglist.component.html',
  styleUrls: ['./admin-ratinglist.component.css']
})
export class AdminRatinglistComponent implements OnInit {

  constructor(private service: ApireviewService, private router: Router) { } // Inject Router service

  reviews: Review[];
  r_id = 1;

  ngOnInit(): void {
    this.service.apiReviewList().subscribe((reviewdata) => {
      this.reviews = reviewdata;
      console.log(this.reviews); // This will log the reviews to the console
    });
  }

  goBack() {
    this.router.navigate(['/admindash']); // Replace '/' with the appropriate route for your back page
  }
}
