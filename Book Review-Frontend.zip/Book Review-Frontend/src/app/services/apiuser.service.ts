import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../User';

@Injectable({
  providedIn: 'root'
})
export class ApiuserService {
  sendVerificationEmail: any;

  constructor(private http: HttpClient) { }

  addUser(data: any) {
    return this.http.post(`http://localhost:8082/api/user/newregister`, data);
  }

  userLogin(data1: any) {
    return this.http.post(`http://localhost:8082/api/user/login`, data1);
  }

  resetPassword(email: string, password: string, newPassword: string): Observable<any> {
    const data = { email: email, newPassword: newPassword };
    return this.http.post('http://localhost:8082/api/user/updatepassword', data);
  }

  getUserByID(val: any) {
    return this.http.get(`http://localhost:8082/api/user/get/${val}`);
  }

  supUser(val: any, id: number) {
    return this.http.post(`http://localhost:8082/api/user/userupdate/${id}`, val);
  }


}
