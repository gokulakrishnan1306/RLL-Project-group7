package com.bookreview;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserChangePassword {
	    private String oldPassword;
	    private String newPassword;
	    private String confirmPassword;
	    public UserChangePassword(String oldPassword, String newPassword, String confirmPassword) {
	        this.oldPassword = oldPassword;
	        this.newPassword = newPassword;
	        this.confirmPassword = confirmPassword;
	    }
	    public String getEmail() {
	    	String email; // Declaration
	    	email = "johnwick07@gmail.com";
	        return email;
	    }
	    public String getOldPassword() {
	    	String OldPassword;
	    	OldPassword="9876";
	    	return OldPassword;
	    	}
	    public String getNewPassword() {
	    	String NewPassword;
	    	NewPassword="1234";
	    	return NewPassword;
	    }
	    
	    // Other methods and fields...
}


