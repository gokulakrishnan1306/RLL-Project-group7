package com.bookreview;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserChangePasswordTest {

    @Test
    public void testUserChangePassword() {
        String email = "johnwick07@gmail.com";
        String oldPassword = "9876";
        String newPassword = "1234";

        UserChangePassword userChangePassword = new UserChangePassword(email, oldPassword, newPassword);

        assertEquals(email, userChangePassword.getEmail());
        assertEquals(oldPassword, userChangePassword.getOldPassword());
        assertEquals(newPassword, userChangePassword.getNewPassword());
    }

}