package com.bookreview;


import com.bookreview.controllers.ReviewController;
import com.bookreview.entity.Review;
import com.bookreview.service.ReviewService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ReviewControllerTest {

    @Mock
    private ReviewService reviewService;

    @InjectMocks
    private ReviewController reviewController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(reviewController).build();
    }

    @Test
    void testAddReview() throws Exception {
        Review review = new Review();
        when(reviewService.save(any(Review.class))).thenReturn(review);

        RequestBuilder requestBuilder = post("/api/review/add")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}");

        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andReturn();

        assertNotNull(result);
        verify(reviewService, times(1)).save(any(Review.class));
    }

    @Test
    void testDeleteReview() throws Exception {
        RequestBuilder requestBuilder = delete("/api/review/deleteReview/{book_name}", "BookName");

        mockMvc.perform(requestBuilder)
                .andExpect(status().isOk());

        verify(reviewService, times(1)).deleteReview("BookName");
    }

    @Test
    void testGetAllReviews() throws Exception {
        List<Review> reviewList = new ArrayList<>();
        when(reviewService.getAllreview()).thenReturn(reviewList);

        RequestBuilder requestBuilder = get("/api/review/list");

        ResultActions resultActions = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        assertNotNull(result);

        verify(reviewService, times(1)).getAllreview();
    }
}
