package com.bookreview.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.bookreview.entity.UserDetails;
import com.bookreview.repo.UserRepository;



@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired  
    JdbcTemplate jdbc; 
	
	public UserDetails getUserByEmail(String email) {
		return userRepository.findUserByEmail(email);
	}
	
	public List<UserDetails> listAll()
	{
		return userRepository.findAll();
	}
	
	public UserDetails save(UserDetails user) {
		return userRepository.save(user);
		
	}
	public UserDetails FindByid(int id) {
		UserDetails user=userRepository.findById(id).get();
		return user;
	}

	public ResponseEntity<String> updatePassword(String email, String newPassword) {
		List<UserDetails> users = userRepository.findAll();
		for(UserDetails user : users)
		{
			if(user.getEmail().equals(email))
			{
				System.out.println(user+" "+email+" "+newPassword);
				user.setPassword(newPassword);
				userRepository.save(user);
				return new ResponseEntity<>("The Password for user "+user.getFirstname()+" was updated successfully", HttpStatus.OK);
			}
		}
		return new ResponseEntity<>("Reset Password Successfully",HttpStatus.BAD_REQUEST);
	}
	
}
